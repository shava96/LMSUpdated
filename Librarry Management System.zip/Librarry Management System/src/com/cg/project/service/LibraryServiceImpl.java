package com.cg.project.service;

public class LibraryServiceImpl implements LibraryService {

}
