package com.cg.project.ui;

import java.util.Scanner;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.dao.LibraryDAOImpl;
import com.cg.project.dao.LibraryDao;
import com.cg.project.exception.LibraryException;
import com.cg.project.service.LibraryService;
import com.cg.project.service.LibraryServiceImpl;


public class LibraryMain {

	public static void main(String[] args) throws LibraryException {
		
		LibraryDao daoRef = new LibraryDAOImpl();
		LibraryService serRef = new LibraryServiceImpl();
		UserBean ub = new UserBean();
		BooksBean bb = new BooksBean();
		BookRegistrationBean br = new BookRegistrationBean();
		TransactionBean tb = new TransactionBean();
		
		
		Scanner sc = new Scanner(System.in);
		
		while(true){
		System.out.println("**********Welcome to Library Management Sysytem************");
		System.out.println("");
		System.out.println("******************* Login Page ***************************** ");
		System.out.println("");
		System.out.print("Enter User ID: ");
		int userid = sc.nextInt();
		System.out.print("\nEnter Password: ");
		String password = sc.next();
		
		String var= daoRef.isValidLibrarian(userid, password);
		while(true)
		{
		
		if(var.equalsIgnoreCase("y")){
			
			ub=daoRef.getData(userid);
			System.out.println("Welcome Librarian....."+ub.getUserName());
			System.out.println("");
			System.out.println("User Id: "+ub.getUserId());
			System.out.println("Email Id: "+ub.getEmailId());
			System.out.println("");
			System.out.println("************MENU***************");
			System.out.println("");
			System.out.println("Press 1. Add a Book");
			System.out.println("Press 2. Delete a Book");
			System.out.println("Press 3. View Books List");
			System.out.println("Press 4. View Issued Books");
			System.out.println("Press 5. Log Out");
			System.out.print("Enter Your Choice: ");
			
			int choice=sc.nextInt();
			
			switch(choice){
			
			case 1: 
				System.out.println("Enter Book Name: "+" ");
				bb.setBookName(sc.next());
				System.out.println(" ");
				System.out.println(" "+"Enter Author1 Name: ");
				bb.setAuthor1(sc.next());
				System.out.println(" "+"Enter Author2 Name: ");
				bb.setAuthor2(sc.next());
				System.out.println("Enter Publication Name: ");
				bb.setPublications(sc.next());
				System.out.println("Enter Year Of Publication: ");
				bb.setYearofpublication(sc.next());
				boolean flag = daoRef.addBooks(bb);
				if(flag==true){
				System.out.println("Book "+bb.getBookName()+" entered into database..");
				}
				else {
					System.out.println("Book didn't entered into database..");
				}
				break;
				
			case 2:
				System.out.println("Enter Book Id to delete: ");
				int bid=sc.nextInt();
				//bb.setBookId(bid);
				daoRef.deleteBooks(bid);
				
				System.out.println("Book with book id:"+bid+" is succesfully Deleted..");
				break;
				
			case 3:
				
				System.out.println("***********Library Book List******************");
				System.out.println("");
				System.out.println("Book id           Book Name         Author1           Author2        Publication_Name     YOP");
				daoRef.showBooks();
				break;
				
			case 4:
				
				break;
				
			case 5:
				System.out.println("Successfully logged out..");
				System.exit(0);
				
			}
		     	
			
			//break;
		}
		
		else
			if(var.equalsIgnoreCase("n"))
		{
				ub=daoRef.getData(userid);
			System.out.println("Welcome Student..."+ub.getUserName());
			System.out.println("");
			System.out.println("User Id: "+ub.getUserId());
			System.out.println("Email Id: "+ub.getEmailId());
			System.out.println("");
			System.out.println("************MENU***************");
			System.out.println("");
			
			System.out.println("Press 1. View Books List");
			System.out.println("Press 2. Issue Books");
			System.out.println("Press 3. View Past Transactions");
			System.out.println("Press 4. Log Out");
			System.out.print("Enter Your Choice: ");
			
            int choice=sc.nextInt();
			
			switch(choice){
		case 1:
			
			System.out.println("***********Library Book List******************");
			System.out.println("");
			System.out.println("Book id           Book Name         Author1           Author2        Publication_Name     YOP");
			daoRef.showBooks();
			break;
			
		case 2:
			System.out.println("**********Issue a Book (By entering book id)************");
			System.out.println();
			System.out.print("Enter Book ID to Issue Book");
			int bid = sc.nextInt();
			boolean flag = daoRef.issueBooks(bid);
			if(flag==true){
				int rid=daoRef.getRid(ub.getUserId());
				daoRef.transactions(rid);
				System.out.println("Book with book id:"+bid+" has been issued successfully and your Registration id is: "+rid);
			}
			else
			{
				System.out.println("Book not issued..");
			}
		
		case 3:
			
			 
			
			}
		}

			else
			{
				System.out.println(" Invalid User..please try again");
			}
		
		
		}
		
	}

}
}