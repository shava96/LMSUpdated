package com.cg.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.exception.LibraryException;
import com.cg.project.utils.DBUtils;

public class LibraryDAOImpl implements LibraryDao {

	private Connection dbConnection;

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
}

	
	//generating user id automatically......
	
	public int generateNextUserId() throws SQLException {
		  int id = 0;

		String selectQuery = "select useridseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
	
		
		return id;
	}
	
	
	// to add user..............
	
	@Override
	public boolean addUser(UserBean user) throws LibraryException {
		
		String insertQuery ="insert into usertable values(?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextUserId());
			insertStatement.setString(2, user.getUserName());
			insertStatement.setString(3, user.getPassword());
			insertStatement.setString(4, user.getEmailId());
			insertStatement.setString(5, user.getLibrarian());
			
			int rows = insertStatement.executeUpdate();
			if(rows>0){
				System.out.println("New User Added..");
				//log.info("New User is Added");
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
		
		
	}
	
	
	//delete a User..
	
	public boolean delUser(int uid) throws LibraryException {
		
    String deleteQuery ="delete from usertable where user_id = ? and librarian=?";
		
		PreparedStatement deleteStatement;
		try {
			deleteStatement = dbConnection.prepareStatement(deleteQuery);
			
			deleteStatement.setInt(1, uid);
			deleteStatement.setString(2, "n");
		
			deleteStatement.executeQuery();
			
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    throw new LibraryException("invalid user id ...please try again");
		}
		
		//return false;
	}
	
	
	
	
	
	
	//generating book id automatically..

	public int generateNextBookId() throws SQLException {
		int id = 0;

		String selectQuery = "select bookidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}

	
	
	//adding Books........
	
	@Override
	public boolean addBooks(BooksBean abooks) throws LibraryException {
		
		String insertQuery ="insert into bookinventory values(?,?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextBookId());
			
			insertStatement.setString(2, abooks.getBookName());
			
			insertStatement.setString(3, abooks.getAuthor1());
			
			insertStatement.setString(4, abooks.getAuthor2());
			
			insertStatement.setString(5, abooks.getPublications());
			
			insertStatement.setString(6, abooks.getYearofpublication());
			
			int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New Book Added..");
				//log.info("New Book is Added");
				
			}
			return true;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
		
	}

	
	
	//Deleting Books...

	@Override
	public BooksBean deleteBooks(int bookId) throws  LibraryException {
		
		String deleteQuery ="delete from bookinventory where book_id = ?";
		
		PreparedStatement deleteStatement;
		try {
			deleteStatement = dbConnection.prepareStatement(deleteQuery);
			
			deleteStatement.setInt(1, bookId);
			
			deleteStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	
		return null;
	}

	
	
	//Generating Registration Id Automatically......
	
	public int generateNextRegId() throws SQLException {
		int id = 0;

		String selectQuery = "select regidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	
	
	
	//issue a book.......
	
	@Override
	public Boolean issueBooks(int bookId) throws  LibraryException {
		
		//BooksBean book = new BooksBean();
		BookRegistrationBean br = new BookRegistrationBean();
		UserBean user = new UserBean();
        String insertQuery ="insert into bookreg values(?,?,?,sysdate)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextRegId());
			insertStatement.setInt(2, bookId);
			insertStatement.setInt(3, user.getUserId() );
			//insertStatement.setDate(4, (Date) br.getRegistrationdate());
			
			insertStatement.executeUpdate();
			return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			throw new LibraryException("Book can't be issued due to some reason..");
		}
	}
	
	//to generate transaction id..
	
	public int generateNextTransId() throws SQLException {
		int id = 0;

		String selectQuery = "select transidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	
	
	
	
	//transaction.........

	@Override
	public boolean transactions(int rid) throws LibraryException {
		
     String insertQuery ="insert into bookreg values(?,?,sysdate,sysdate+14)";
		BookRegistrationBean br = new BookRegistrationBean();
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextTransId());
			insertStatement.setInt(2, rid);
			
              int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New transaction is completed successfully.. ");
				//log.info("New Book is Added");
				
			}
			
			
			return true;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
	
		
	}
	
	
	//reterieving new user id..
	public int getnewuserid(String email) throws LibraryException{
	
		int uid=0;
		String  query = "Select user_id from usertable where email = ?";
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setString(1, email);
			
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
			uid = result.getInt(1);
			
			return uid;
     	}
     	}catch(SQLException e){
     		e.printStackTrace();
     		//throw new LibraryException();
     		
     	}
		
		return uid;
	}
	
	
	
	//retrieving registration id..
	
	
	public int getRid(int uid) throws LibraryException{
		
		String  query = "Select registration_id from bookreg where user_id = ?";
     	//UserBean ub = new UserBean();
     	int rid=0;
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, uid);
			//insertStatement.setString(2, password);
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
			rid = result.getInt(1);
			
			return rid;
     	}
     	}catch(SQLException e){
     		e.printStackTrace();
     		//throw new LibraryException();
     		
     	}
		
		
		return rid;
	}
	
	
	//displaying all books.........

	@Override
	public void showBooks() throws LibraryException {
		
		
		
		String selectQuery = "select * from bookinventory";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int bid = result.getInt(1);
				String bname = result.getString(2);
				String a1 = result.getString(3);
				String a2 = result.getString(4);
				String pub = result.getString(5);
				String year = result.getString(6);
				
				BooksBean b = new BooksBean();
				
				b.setBookId(bid);
				b.setAuthor1(a1);
				b.setAuthor2(a2);
				b.setBookName(bname);
				b.setPublications(pub);
				b.setYearofpublication(year);
				
				System.out.println(bid +"   "+  bname+"   "+ a1+"   "+ a2+"   " + pub+"   "+year);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	
	//Display all users..
	
public void showUsers() throws LibraryException {
		
		
		
		String selectQuery = "select * from usertable";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int uid = result.getInt(1);
				String uname = result.getString(2);
				
				String email = result.getString(4);
				String lib = result.getString(5);
				
				
				UserBean ub = new UserBean();
				
				ub.setUserId(uid);
				ub.setUserName(uname);
				ub.setEmailId(email);
				ub.setLibrarian(lib);
				
				
				System.out.println(uid +"   "+  uname+"   "+ email+"   "+ lib);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LibraryException("No users to display");
		}
		
		
		
	}
	
//Retrive all data from usertable per userid..
	

	public UserBean getData(int userid) throws LibraryException{
		
		String  query = "Select * from usertable where user_id = ?";
		UserBean ub = new UserBean();
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
				
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String mail = result.getString(4);
			String lib ="";
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setPassword(userpass);
			ub.setEmailId(mail);
			ub.setLibrarian(lib);
			
			return ub;
			
			}
			
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			 throw new LibraryException();
		}
	return ub;
}

public String isValidLibrarian(int userid,String password) throws LibraryException{
	
     	String  query = "Select * from usertable where user_id = ?";
     	UserBean ub = new UserBean();
     	String lib=""; 
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			//insertStatement.setString(2, password);
			
			ResultSet result = insertStatement.executeQuery();
			
			
			while(result.next()){
			
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String email = result.getString(4);
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setEmailId(email);
			ub.setLibrarian(lib);
			if(userpass.equals(password)){
				
			System.out.println("Valid User...");
			//Log.info("Valid User..");
			
			
			return lib;
				
				
			}
			
			}
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			throw new LibraryException("Login Failed..try again");
			
     	}
     	return lib;
}


//Reterive all data from BookRegistration table..per user id..

public BookRegistrationBean getRegData(int uid) {
	
	String  query = "Select * from bookreg where user_id = ?";
	//UserBean ub = new UserBean();
	BookRegistrationBean br = new BookRegistrationBean();
	try {
		PreparedStatement insertStatement = dbConnection.prepareStatement(query);
	    
		insertStatement.setInt(1, uid);
		
		
		ResultSet result = insertStatement.executeQuery();
		
		while(result.next()){
			
			
		int rid = result.getInt(1);
		int bookid=result.getInt(2);
		int userid=result.getInt(3);
		Date regdate=result.getDate(4);
		
		br.setRegistration_id(rid);
		br.setBook_id(bookid);
		br.setUser_id(userid);
		br.setRegistrationdate(regdate);
		
		return br;
		
		}
		
		
 	} catch (SQLException e) {
		
		e.printStackTrace();
		//LibraryException("");
		//log.error(e.getMessgae);
		// throw new LibraryException();
	}
	
	return br;
}


//Reterive all data from BookRegistration table..per registration id.

public TransactionBean getTransData(int rid) {
	
	String  query = "Select * from booktransaction where user_id = ?";
	//UserBean ub = new UserBean();
	TransactionBean tb = new TransactionBean();
	//BookRegistrationBean br = new BookRegistrationBean();
	try {
		PreparedStatement insertStatement = dbConnection.prepareStatement(query);
	    
		insertStatement.setInt(1, rid);
		
		
		ResultSet result = insertStatement.executeQuery();
		
		while(result.next()){
			
			
		int tid = result.getInt(1);
		int regid=result.getInt(2);
		Date idate=result.getDate(3);
		Date rdate=result.getDate(4);
		
		tb.setTransaction_id(tid);
		tb.setRegistration_id(regid);
		tb.setIssue_date(idate);
		tb.setReturn_date(rdate);
		
		
		return tb;
		
		}
		
		
 	} catch (SQLException e) {
		
		e.printStackTrace();
		//LibraryException("");
		//log.error(e.getMessgae);
		// throw new LibraryException();
	}
	
	
	return tb;
}


//reterive issued books (by passing user id in bookreg table, then reteriving book id from it then pass that into book inventory table).

public BooksBean getbook(int bid) throws LibraryException {
	
	BooksBean bb = new BooksBean();
	
	String selectQuery = "select * from bookinventory where book_id=?";
	
	try {
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
		
		selectStatement.setInt(1, bid);
        ResultSet result = selectStatement.executeQuery();
		
		while (result.next()) {
		
			int id = result.getInt(1);
			String bname = result.getString(2);
			String a1 = result.getString(3);
			String a2 = result.getString(4);
			String pub = result.getString(5);
			String year = result.getString(6);
			
			
			
			bb.setBookId(id);
			bb.setAuthor1(a1);
			bb.setAuthor2(a2);
			bb.setBookName(bname);
			bb.setPublications(pub);
			bb.setYearofpublication(year);
			
			return bb;			
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new LibraryException("Book Not Found...");
	}
	return bb;
	
}






//return a book (by deleting that issued book from bookreg table..)



//Date formator




//calculate fine...









}


