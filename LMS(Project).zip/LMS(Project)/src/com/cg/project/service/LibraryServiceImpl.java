package com.cg.project.service;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.dao.LibraryDAOImpl;
import com.cg.project.dao.LibraryDao;
import com.cg.project.exception.LibraryException;

public class LibraryServiceImpl implements LibraryService {

	LibraryDao dao=new LibraryDAOImpl();
	@Override
	public boolean addUser(UserBean user) throws LibraryException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addBooks(BooksBean abooks) throws LibraryException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public BooksBean deleteBooks(int bookId) throws LibraryException {
		// TODO Auto-generated method stub
		return dao.deleteBooks(bookId);
	}

	@Override
	public Boolean issueBooks(int bookId, int uid) throws LibraryException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean transactions(int rid) throws LibraryException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void showBooks() throws LibraryException {
		// TODO Auto-generated method stub
      return;
	}

	@Override
	public int getnewuserid(String email) throws LibraryException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRid(int uid) throws LibraryException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String isValidLibrarian(int userid, String password) throws LibraryException {
		// TODO Auto-generated method stub
		return dao.isValidLibrarian(userid, password);
	}

	@Override
	public UserBean getData(int userid) throws LibraryException {
		// TODO Auto-generated method stub
		return dao.getData(userid);
	}

	@Override
	public BookRegistrationBean getRegData(int uid) {
		// TODO Auto-generated method stub
		return dao.getRegData(uid);
	}

	@Override
	public TransactionBean getTransData(int rid) {
		// TODO Auto-generated method stub
		return dao.getTransData(rid);
	}

	@Override
	public boolean delUser(int uid) throws LibraryException {
		// TODO Auto-generated method stub
		return false;
	}

}
