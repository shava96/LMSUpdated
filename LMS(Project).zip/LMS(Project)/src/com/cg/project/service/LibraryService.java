package com.cg.project.service;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.exception.LibraryException;

public interface LibraryService {
	
	public boolean  addUser(UserBean user) throws  LibraryException;
	public boolean addBooks(BooksBean abooks) throws  LibraryException;
	public BooksBean deleteBooks(int bookId) throws  LibraryException;
	public Boolean issueBooks(int bookId,int uid) throws  LibraryException;
	public boolean transactions(int rid) throws  LibraryException;
	
	//displaying details......................
	
	public void showBooks() throws  LibraryException;
	
	/*public UserBean getValidation(int userid,String password) throws LibraryException;*/
	
	public int getnewuserid(String email) throws LibraryException;
	public int getRid(int uid) throws LibraryException;
	public String isValidLibrarian(int userid,String password) throws LibraryException;
	public UserBean getData(int userid) throws LibraryException;
	public BookRegistrationBean getRegData(int uid);
	public TransactionBean getTransData(int rid);
	public boolean delUser(int uid) throws LibraryException;

}
