package com.cg.project.ui;

import java.text.ParseException;
import java.util.Scanner;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.dao.LibraryDAOImpl;
import com.cg.project.dao.LibraryDao;
import com.cg.project.exception.LibraryException;
import com.cg.project.service.LibraryService;
import com.cg.project.service.LibraryServiceImpl;


public class LibraryMain {

	public static void main(String[] args) throws LibraryException, ParseException {
		
		LibraryDao daoRef = new LibraryDAOImpl();
		LibraryService serRef = new LibraryServiceImpl();
		UserBean ub = new UserBean();
		BooksBean bb = new BooksBean();
		BookRegistrationBean br = new BookRegistrationBean();
		TransactionBean tb = new TransactionBean();
		
		
		Scanner sc = new Scanner(System.in);
		
		while(true){
		System.out.println();	
		System.out.println("**********Welcome to Library Management Sysytem************");
		System.out.println("");
		System.out.println("******************* Login Page ***************************** ");
		System.out.println("");
		System.out.print("Enter User ID: ");
		int userid = sc.nextInt();
		System.out.print("\nEnter Password: ");
		String password = sc.next();
		
		String var= daoRef.isValidLibrarian(userid, password);
		while(true)
		{
		
		if(var.equalsIgnoreCase("y")){
			
			ub=daoRef.getData(userid);
			System.out.println("Welcome Librarian....."+ub.getUserName());
			System.out.println("");
			System.out.println("User Id: "+ub.getUserId());
			System.out.println("Email Id: "+ub.getEmailId());
			System.out.println("");
			System.out.println("************MENU***************");
			System.out.println("");
			System.out.println("Press 1. Add a Book");
			System.out.println("Press 2. Delete a Book");
			System.out.println("Press 3. View Books List");
			System.out.println("Press 4. Issue a Book");
			System.out.println("Press 5. Return a Book");
			System.out.println("Press 6. View Issued Books");
			System.out.println("Press 7. Add a new user");
			System.out.println("Press 8. Delete a user");
			System.out.println("Press 9. Log Out");
			System.out.print("Enter Your Choice: ");
			
			int choice=sc.nextInt();
			
			switch(choice){
			
			case 1: 
				System.out.println("Enter Book Name: "+" ");
				bb.setBookName(sc.next());
				System.out.println(" ");
				System.out.println(" "+"Enter Author1 Name: ");
				bb.setAuthor1(sc.next());
				System.out.println(" "+"Enter Author2 Name: ");
				bb.setAuthor2(sc.next());
				System.out.println("Enter Publication Name: ");
				bb.setPublications(sc.next());
				System.out.println("Enter Year Of Publication: ");
				bb.setYearofpublication(sc.next());
				boolean flag = daoRef.addBooks(bb);
				if(flag==true){
				System.out.println("Book "+bb.getBookName()+" entered into database..");
				}
				else {
					System.out.println("Book didn't entered into database..");
				}
				break;
				
			case 2:
				System.out.println("Enter Book Id to delete: ");
				int bid=sc.nextInt();
				//bb.setBookId(bid);
				daoRef.deleteBooks(bid);
				
				System.out.println("Book with book id:"+bid+" is succesfully Deleted..");
				break;
				
			case 3:
				
				System.out.println("***********Library Book List******************");
				System.out.println("");
				System.out.println("Book id           Book Name         Author1           Author2        Publication_Name     YOP");
				daoRef.showBooks();
				break;
				
			case 4:
				System.out.println("**********Issue a Book (By entering book id)************");
				System.out.println();
				System.out.println("Enter user Id: ");
				int ubid=sc.nextInt();
				System.out.print("Enter Book ID to Issue Book");
				int bid1 = sc.nextInt();
				
				boolean flaga = daoRef.issueBooks(bid1,ubid);
				if(flaga==true){
					int rid=daoRef.getRid(ubid);
					daoRef.transactions(rid);
					System.out.println("Book with book id:"+bid1+" has been issued successfully and your Registration id is: "+rid);
				}
				else
				{
					System.out.println("Book not issued..");
				}
				
				break;
				
			case 5:
				//return a book
				System.out.println("user id");
				int uid=sc.nextInt();
				System.out.println("Enter book id ");
				int bookid=sc.nextInt();
				int rid = daoRef.getRegId(uid, bookid);
				//System.out.println(rid);
				daoRef.updateActaulDate(rid);
				long days = daoRef.days(rid);
				//System.out.println(days);
				if(days>14){
					long fine = daoRef.fine(days);
					System.out.println("User have to give fine: "+fine);
					System.out.println("Fine given yes/no");
					String ch=sc.next();
					switch(ch){
					case "yes":
						daoRef.delissuedbook(rid);
						System.out.println("Book whth Book id: "+bookid+"successfully returned with fine "+fine);
						break;
					case "no":
						System.out.println("Please give the fine soon...");
					}
					
				}
				else 
				{
					boolean flag4=daoRef.delissuedbook(rid);
					if(flag4==true){
					System.out.println("Book whth Book id: "+bookid+"successfully returned with no fine.");
					}
					}
				
				break;
				
			case 6:
				//view issued books..
				/*BookRegistrationBean br1 = new BookRegistrationBean();
				br1=daoRef.getRegData(ub.getUserId());
				int bid=*/
				System.out.println("Enter User id:");
				int usid=sc.nextInt();
				daoRef.showissuedBooks(usid);
				
				break;
				
				
				
			case 7:
				UserBean ub1=new UserBean();
				System.out.println("Enter userName:");
				ub1.setUserName(sc.next());
				System.out.println("Enter Password:");
				ub1.setPassword(sc.next());
				System.out.println("Enter email id:");
				ub1.setEmailId(sc.next());
				System.out.println("Enter Y/N:");
				System.out.println("Y-for librarian");
				System.out.println("N-for other users");
				ub1.setLibrarian(sc.next());
				boolean flag2=daoRef.addUser(ub1);
				if(flag2==true) {
					System.out.println("new user added successfully..");
					String mail=ub1.getEmailId();
					int id =  daoRef.getnewuserid(mail);
					System.out.println("Generated User id: "+id);
					System.out.println("Note:Use this user id to sign in");
				}
				else
				{
					System.out.println("New User Not Created ..Please Try Again..");
				}
				
				break;
				
			case 8:
				
				System.out.println("Delete A User");
				System.out.println("Enter that user id: ");
				int id =sc.nextInt();
				boolean  flag3=daoRef.delUser(id);
				if(flag3==true) {
					System.out.println("user deleted succesfully...");
				}
				
				break;
				
		
				
			case 9:
				System.out.println("Successfully logged out..");
				System.exit(0);
				
			default: System.out.println("Invalid choice..");	
			}
		     	
			
			//break;
		}
		
		else
			if(var.equalsIgnoreCase("n"))
		{
				ub=daoRef.getData(userid);
				System.out.println();
			System.out.println("Welcome Student..."+ub.getUserName());
			System.out.println("");
			System.out.println("User Id: "+ub.getUserId());
			System.out.println("Email Id: "+ub.getEmailId());
			System.out.println("");
			System.out.println("************MENU***************");
			System.out.println("");
			
			System.out.println("Press 1. View Books List");
			//System.out.println("Press 2. Issue a Book");
			//System.out.println("Press 2. Return a Book");
			System.out.println("Press 2. View Past Transactions");
			System.out.println("Press 3. Log Out");
			System.out.print("Enter Your Choice: ");
			
            int choice=sc.nextInt();
			
			switch(choice){
		case 1:
			
			System.out.println("***********Library Book List******************");
			System.out.println("");
			System.out.println("Book id		Book Name		Author1		Author2		Publication_Name	YOP");
			daoRef.showBooks();
			break;
			
		
		
		/*case 2:
			 //...
			
			break;*/

		
		
		case 2:
			
			System.out.print("Enter Registration id:");
			int regid=sc.nextInt();
			tb=daoRef.getTransData(regid);
			System.out.println("Transaction id: "+tb.getTransaction_id());
			System.out.println("Registraton id: "+tb.getRegistration_id());
			System.out.println("Issue Date    : "+tb.getIssue_date());
			System.out.println("Return Date   : "+tb.getReturn_date());
			
			 break;
			 
			 
					
		case 3:	
			System.out.println("Successfully logged out..");
			System.exit(0);
		
		default: System.out.println("Invalid choice..");	
			}
		}

			else
			{
				System.out.println(" Invalid User..please try again");
			}
		
		
		}
		
	}

}
}