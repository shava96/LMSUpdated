package com.cg.bean.books;

public class BooksBean {
private int bookId;
private String bookName;
private String author1;
private String author2;
private String publications;
private String yearofpublication;

public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}
public String getBookName() {
	return bookName;
}
public void setBookName(String bookName) {
	this.bookName = bookName;
}
public String getAuthor1() {
	return author1;
}
public void setAuthor1(String author1) {
	this.author1 = author1;
}
public String getAuthor2() {
	return author2;
}
public void setAuthor2(String author2) {
	this.author2 = author2;
}
public String getPublications() {
	return publications;
}
public void setPublications(String publications) {
	this.publications = publications;
}
public String getYearofpublication() {
	return yearofpublication;
}
public void setYearofpublication(String yearofpublication) {
	this.yearofpublication = yearofpublication;
}
}
